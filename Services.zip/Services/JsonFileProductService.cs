﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Amatorio_RogieIP.website.Models;
using Microsoft.AspNetCore.Hosting;

namespace Amatorio_RogieIP.website.Services
{
    public class JSONFileProductServices
    {
        public class JSONFileProductService
        {
            public JSONFileProductService(IWebHostEnvironment webHostEnvironment)
            {
                WebHostEnvironment = webHostEnvironment;
            }

            public IWebHostEnvironment WebHostEnvironment { get; }

            private string JsonFileName
            {
                get { return Path.Combine(WebHostEnvironment.WebRootPath, "data", "products.json"); }
            }

            public IEnumerable<Product> GetProducts()
            {
                using (var jsonFileReader = File.OpenText(JsonFileName))
                {
                    return JsonSerializer.Deserialize<Product[]>(jsonFileReader.ReadToEnd(),
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });
                }
            }

            public void AddRating(string productId, int Rating)
            {
                var Products = GetProducts();

                var query = Products.First(x => x.Id == productId);

                if (query.Ratings == null)
                {
                    query.Ratings = new int[] { Rating };
                }
                else
                {
                    var Ratings = query.Ratings.ToList();
                    Ratings.Add(Rating);
                    query.Ratings = Ratings.ToArray();
                }

                using (var outputStream = File.OpenWrite(JsonFileName))
                {
                    JsonSerializer.Serialize<IEnumerable<Product>>(
                        new Utf8JsonWriter(outputStream, new JsonWriterOptions
                        {
                            SkipValidation = true,
                            Indented = true
                        }),
                        Products
                    );
                }
            }
        }

        internal void AddRating(string productId, int rating)
        {
            throw new NotImplementedException();
        }

        internal IEnumerable<Product> GetProducts()
        {
            throw new NotImplementedException();
        }
    }
}